import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class FenixVision extends StatefulWidget {
  const FenixVision({super.key});
  @override
  State<FenixVision> createState() => _FenixVisionState();
}


class _FenixVisionState extends State<FenixVision> {
  final ImagePicker _picker = ImagePicker();
  File? _image;
  bool _loading = false;
  static const Color black = Color(0xFF101010);
  static const Color gold = Color(0xFFD4AF37);

  Future<void> selectImage() async {
    try {
      final selected = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
      if (selected != null && mounted) setState(() => _image = File(selected.path));
    } catch (_) { if (mounted) showMessage('Error al seleccionar imagen'); }
  }

  Future<void> takePhoto() async {
    try {
      final selected = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
      if (selected != null && mounted) setState(() => _image = File(selected.path));
    } catch (_) { if (mounted) showMessage('Error al abrir cámara'); }
  }

  void showMessage(String message) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(message), backgroundColor: Colors.black87));


  void visionAction(String action) {
    if (_image == null) { showMessage('Primero seleccioná una imagen'); return; }
    showMessage('$action: módulo pendiente de integración IA');
  }


  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: black,
    appBar: AppBar(backgroundColor: black, elevation: 0,
      title: const Row(children: [Icon(Icons.remove_red_eye, color: gold), SizedBox(width: 10),
        Text('FÉNIX VISION', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.5))])),
    body: SafeArea(child: Column(children: [
      Expanded(child: Container(width: double.infinity, margin: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFF1B1B1B), border: Border.all(color: gold.withOpacity(.4)), borderRadius: BorderRadius.circular(18)),
        child: _image == null ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.image_search, size: 85, color: gold), SizedBox(height: 18),
          Text('CENTRO DE INTELIGENCIA VISUAL', style: TextStyle(color: gold, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('Seleccioná una imagen para comenzar', style: TextStyle(color: Colors.white54))
        ])) : ClipRRect(borderRadius: BorderRadius.circular(18), child: InteractiveViewer(minScale: .5, maxScale: 5,
          child: Image.file(_image!, fit: BoxFit.contain, width: double.infinity, height: double.infinity)))),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), child: Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
        visionButton(Icons.photo_library, 'Galería', selectImage), visionButton(Icons.camera_alt, 'Cámara', takePhoto),
        visionButton(Icons.auto_awesome, 'Mejorar', () => visionAction('Mejorar imagen')),
        visionButton(Icons.search, 'Analizar', () => visionAction('Analizar imagen')),
        visionButton(Icons.person_remove, 'Eliminar fondo', () => visionAction('Eliminar fondo')),
        visionButton(Icons.palette, 'Editar IA', () => visionAction('Edición inteligente')),
      ])),
      const SizedBox(height: 12), Container(width: double.infinity, padding: const EdgeInsets.all(14), color: const Color(0xFF151515),
        child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.memory, color: gold, size: 16), SizedBox(width: 8),
          Text('FÉNIX VISION ENGINE', style: TextStyle(color: gold, fontSize: 11, letterSpacing: 2))]))
    ])),
  );


  Widget visionButton(IconData icon, String label, VoidCallback onTap) => SizedBox(width: 105, height: 85,
    child: ElevatedButton(onPressed: _loading ? null : onTap, style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF252525), foregroundColor: gold,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: gold.withOpacity(.35))),
      padding: const EdgeInsets.all(8)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 27), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11))
    ])));
}
