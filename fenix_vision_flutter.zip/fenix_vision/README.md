# FÉNIX VISION — Flutter starter module


## 1) Add dependencies to `pubspec.yaml`
Add under `dependencies` (keep your existing dependencies):
```yaml
image_picker: ^1.2.0
image: ^4.5.0
```
Then run:
```bash
flutter pub get
```

## 2) Copy the module
Copy `lib/modules/vision/fenix_vision.dart` into the same path in your Flutter project.

## 3) Open it from your app
Import:
```dart
import 'modules/vision/fenix_vision.dart';
```
Navigate:
```dart
Navigator.push(context, MaterialPageRoute(builder: (_) => const FenixVision()));
```

## Current functionality
- Pick an image from gallery
- Capture an image from camera
- View image and zoom/pan
- Black-and-gold UI

The AI buttons are placeholders and do not yet perform enhancement, analysis, background removal, or generative editing.


## Platform notes
`image_picker` may require platform permissions/configuration. Review its official package instructions for Android/iOS setup. Test on your target device after `flutter pub get`.
